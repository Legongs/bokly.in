"use server";

import { z } from "zod";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createClient as createAdminClient } from "@supabase/supabase-js";
import { checkRateLimit } from "@/lib/rate-limit";
import type { ActionResponse } from "./tenant.actions";

// ── Schemas (Tone of Voice: Kasual & Ramah) ───────────────────────────────────

const loginSchema = z.object({
  email: z.string().email("Format email-nya kurang pas nih."),
  password: z.string().min(6, "Password minimal 6 karakter ya."),
});

const registerSchema = z.object({
  email: z.string().email("Format email-nya kurang pas nih."),
  password: z.string().min(6, "Password minimal 6 karakter biar aman ya."),
  business_name: z
    .string()
    .min(2, "Nama bisnis minimal 2 huruf ya.")
    .max(100, "Kepanjangan nih, maksimal 100 huruf aja ya.")
    .trim(),
  business_sector: z.enum(["beauty", "space", "auto", "health"]),
  business_type: z.string().min(1, "Sub sektor bisnis harus dipilih ya."),
  whatsapp_number: z
    .string()
    .min(10, "Nomor WA kependekan, minimal 10 angka ya.")
    .max(16, "Nomor WA kepanjangan, maksimal 16 angka ya.")
    .regex(
      /^(\+62|62|0)8[1-9][0-9]{6,11}$/,
      "Format WA-nya kurang pas. Pakai awalan 08 atau 628 ya."
    ),
  slug: z
    .string()
    .min(3, "URL toko minimal 3 huruf ya.")
    .max(50, "URL toko maksimal 50 huruf ya.")
    .regex(/^[a-z0-9-]+$/, "Cuma boleh pakai huruf kecil, angka, dan strip (-) ya.")
    .trim(),
});

export type LoginPayload = z.infer<typeof loginSchema>;
export type RegisterPayload = z.infer<typeof registerSchema>;

// ── Actions ───────────────────────────────────────────────────────────────────

export async function login(payload: unknown): Promise<ActionResponse<any>> {
  const parsed = loginSchema.safeParse(payload);
  if (!parsed.success) {
    return { success: false, error: parsed.error.issues[0]?.message ?? "Data kurang pas nih." };
  }

  // Rate Limiting: Max 5 attempts per 5 minutes per email
  const rateLimitKey = `login_${parsed.data.email}`;
  if (!(await checkRateLimit(rateLimitKey, 5, 300_000))) {
    return { success: false, error: "Terlalu banyak percobaan login. Tunggu 5 menit lagi ya." };
  }

  try {
    const supabase = await createClient();
    const { data, error } = await supabase.auth.signInWithPassword({
      email: parsed.data.email,
      password: parsed.data.password,
    });

    if (error) {
      if (error.message.includes("Invalid login credentials")) {
        return { success: false, error: "Email atau password-nya salah nih. Cek lagi yuk!" };
      }
      if (error.message.includes("Email not confirmed")) {
        return { success: false, error: "Email kamu belum dikonfirmasi nih. Cek inbox ya!" };
      }
      return { success: false, error: `Gagal login (${error.message}). Coba muat ulang halamannya ya.` };
    }

    return { success: true, data: data.user };
  } catch {
    return { success: false, error: "Server kita lagi ngambek dikit nih. Coba lagi ya." };
  }
}

export async function checkSlugAvailability(slug: string): Promise<boolean> {
  if (!slug || slug.trim() === "") return false;

  try {
    const supabase = await createClient();
    const { data } = await supabase
      .from("tenants")
      .select("id")
      .eq("slug", slug.trim())
      .single();

    if (data) {
      // Data ditemukan, berarti slug sudah dipakai
      return false;
    }

    // Jika tidak ada data (kemungkinan error PGRST116 - no rows returned), berarti tersedia
    return true;
  } catch (error) {
    // Tangani error tak terduga dengan default false (mencegah pendaftaran bocor)
    return false;
  }
}

export async function register(payload: unknown): Promise<ActionResponse<any>> {
  const parsed = registerSchema.safeParse(payload);
  if (!parsed.success) {
    return { success: false, error: parsed.error.issues[0]?.message ?? "Data kurang pas nih." };
  }

  const { email, password, business_name, business_sector, business_type, whatsapp_number, slug } = parsed.data;

  // Rate Limiting: Max 3 attempts per 10 minutes per email
  const rateLimitKey = `register_${email}`;
  if (!(await checkRateLimit(rateLimitKey, 3, 600_000))) {
    return { success: false, error: "Tunggu sebentar ya sebelum mencoba daftar lagi." };
  }

  try {
    const supabase = await createClient();

    // 1. Cek apakah slug sudah dipakai (Validasi Slug awal)
    const { data: existingTenant } = await supabase
      .from("tenants")
      .select("id")
      .eq("slug", slug)
      .single();

    if (existingTenant) {
      return {
        success: false,
        error: "Yah, URL toko ini udah dipakai orang lain. Coba cari nama lain yuk!",
      };
    }

    // 2. Register ke Supabase Auth
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
    });

    if (authError || !authData.user) {
      if (authError?.message.includes("already registered")) {
        return { success: false, error: "Email ini udah pernah didaftarin. Langsung login aja yuk!" };
      }
      return { success: false, error: "Gagal bikin akun nih. Coba klik sekali lagi ya." };
    }

    const userId = authData.user.id;

    // 3. Insert ke tabel tenants menggunakan Service Role agar tidak terblokir RLS
    // karena session SSR belum terpasang penuh pada request yang sama.
    const adminSupabase = createAdminClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!
    );

    const { error: insertError } = await adminSupabase.from("tenants").insert({
      id: userId,
      slug,
      business_name,
      business_sector,
      business_type,
      whatsapp_number,
    });

    if (insertError) {
      // Jika terjadi race condition (slug diambil di milidetik yang sama)
      if (insertError.code === "23505") {
        return {
          success: false,
          error: "Waduh, URL toko ini baru aja diambil orang lain. Ganti nama dikit yuk!",
        };
      }
      return { success: false, error: "Gagal nyimpen profil toko kamu. Hubungi admin ya." };
    }

    revalidatePath("/dashboard");
    return { success: true, data: authData.user };
  } catch {
    return { success: false, error: "Server kita lagi ngambek dikit nih. Coba lagi ya." };
  }
}

export async function logout(): Promise<ActionResponse<null>> {
  try {
    const supabase = await createClient();
    const { error } = await supabase.auth.signOut();
    if (error) {
      return { success: false, error: "Gagal keluar. Coba lagi ya." };
    }
    return { success: true, data: null };
  } catch {
    return { success: false, error: "Server error saat keluar." };
  }
}

const forgotPasswordSchema = z.object({
  email: z.string().email("Format email kurang pas nih."),
});

export async function sendPasswordResetEmail(email: string): Promise<ActionResponse<null>> {
  const parsed = forgotPasswordSchema.safeParse({ email });
  if (!parsed.success) {
    return { success: false, error: parsed.error.issues[0]?.message };
  }

  // Rate Limiting: Max 3 attempts per 10 minutes per email
  const rateLimitKey = `forgot_${email}`;
  if (!(await checkRateLimit(rateLimitKey, 3, 600_000))) {
    return { success: false, error: "Tunggu sebentar ya sebelum mencoba minta link reset lagi." };
  }

  try {
    const supabase = await createClient();
    const { error } = await supabase.auth.resetPasswordForEmail(parsed.data.email, {
      redirectTo: `${process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'}/auth/callback?next=/reset-password`,
    });

    if (error) {
      return { success: false, error: "Gagal mengirim email reset password. Pastikan email terdaftar." };
    }

    return { success: true, data: null };
  } catch {
    return { success: false, error: "Terjadi kesalahan sistem, coba lagi nanti." };
  }
}

const resetPasswordSchema = z.object({
  password: z.string().min(6, "Password minimal 6 karakter biar aman ya."),
});

export async function resetPassword(password: string): Promise<ActionResponse<null>> {
  const parsed = resetPasswordSchema.safeParse({ password });
  if (!parsed.success) {
    return { success: false, error: parsed.error.issues[0]?.message };
  }

  try {
    const supabase = await createClient();
    
    // Pastikan user memiliki sesi valid dari pertukaran kode (PKCE)
    const { data: authData, error: authError } = await supabase.auth.getUser();
    if (authError || !authData.user) {
      return { success: false, error: "Sesi tidak valid atau telah kedaluwarsa. Silakan minta link reset lagi." };
    }

    const { error } = await supabase.auth.updateUser({
      password: parsed.data.password,
    });

    if (error) {
      return { success: false, error: "Gagal mengatur password baru. Coba lagi." };
    }

    return { success: true, data: null };
  } catch {
    return { success: false, error: "Terjadi kesalahan sistem saat memperbarui password." };
  }
}
